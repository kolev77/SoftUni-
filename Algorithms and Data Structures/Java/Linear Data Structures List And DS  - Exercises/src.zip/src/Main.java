/**
 * Created by Rostislav Kolev on 04-Jun-17.
 */
public class Main {
    ReversedList<Integer> list = new ReversedList<>();
}
