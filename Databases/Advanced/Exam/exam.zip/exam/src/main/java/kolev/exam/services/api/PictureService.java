package kolev.exam.services.api;

import kolev.exam.entities.Picture;

public interface PictureService {
    String add(Picture picture);
}
