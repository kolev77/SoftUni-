package kolev.exam.constants;

public class ResultMessages {
    public static final String SUCCESSFUL = "Successfully imported %s %s.";
    public static final String ERROR = "Error: Invalid data.";

}
