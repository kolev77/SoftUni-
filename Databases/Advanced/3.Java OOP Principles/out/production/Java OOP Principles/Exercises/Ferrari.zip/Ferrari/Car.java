package Exercises.Ferrari;

public interface Car {
    String brakeMsg = "Brakes!";
    String gasMsg = "Zadu6avam sA!";

    String getModel();

    String pushBrakes();

    String pushGasPedal();

    String getDriversName();
}
