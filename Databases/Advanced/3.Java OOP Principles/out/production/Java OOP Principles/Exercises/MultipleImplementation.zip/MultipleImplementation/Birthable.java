package Exercises.MultipleImplementation;

/**
 * Created by Rostislav Kolev on 07-Jul-17.
 */
public interface Birthable {
    String getBirthdate();
}
