package Exercises.MultipleImplementation;

public interface Person {
    String getName();
    int getAge();       // these ara properties
}
