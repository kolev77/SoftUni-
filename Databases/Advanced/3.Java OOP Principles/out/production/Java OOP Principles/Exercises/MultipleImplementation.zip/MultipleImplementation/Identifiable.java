package Exercises.MultipleImplementation;


public interface Identifiable {
    String getId();
}
