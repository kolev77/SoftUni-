package Exercises.Telephony;


public interface Browsing {
    String browsingMsg = "Browsing: ";

    String browse(String url);
}
