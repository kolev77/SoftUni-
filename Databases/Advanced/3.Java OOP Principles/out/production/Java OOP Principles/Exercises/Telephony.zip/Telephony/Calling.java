package Exercises.Telephony;

public interface Calling {
    String callMsg = "Calling... ";

    String call(String number);
}
