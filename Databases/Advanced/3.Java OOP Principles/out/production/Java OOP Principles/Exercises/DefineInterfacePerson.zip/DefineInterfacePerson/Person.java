package Exercises.DefineInterfacePerson;

public interface Person {
    String getName();
    int getAge();       // these ara properties
}
