package softuni.softuni.dtos.utility;

public class LensIdUtilityDto {
    private long id;

    public LensIdUtilityDto() {
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }
}