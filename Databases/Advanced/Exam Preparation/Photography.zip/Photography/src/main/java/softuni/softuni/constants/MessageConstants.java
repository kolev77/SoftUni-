package softuni.softuni.constants;

public final class MessageConstants {
    public static final String INVALID_INPUT_DATA_MESSAGE = "Error. Invalid data provided";

    private MessageConstants() {}
}