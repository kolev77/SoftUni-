package Exercises.BirthdayCelebrations;

public interface Natality {
    String getName();
    String getBirthdate();
}
