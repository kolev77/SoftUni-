package Exercises.BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
