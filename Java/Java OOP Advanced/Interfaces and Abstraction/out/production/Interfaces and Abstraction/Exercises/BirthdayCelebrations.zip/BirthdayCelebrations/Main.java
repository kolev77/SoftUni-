package Exercises.BirthdayCelebrations;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        List<Natality> creatures = new ArrayList<>();
        List<Robot> robots = new ArrayList<>();

        readInput(br, creatures, robots);

        printSelectedBirthDates(br, creatures);

    }

    private static void printSelectedBirthDates(BufferedReader br, List<Natality> creatures) throws IOException {
        String inputYear = br.readLine();
        List<Natality> collectedCreatures = creatures.stream().filter(c -> c.getBirthdate().endsWith(inputYear)).collect(Collectors.toList());

        if (collectedCreatures.size() != 0) {
            collectedCreatures.forEach(c -> System.out.println(c.getBirthdate()));
        } else {
            System.out.println("<no output>");
        }
    }

    private static void readInput(BufferedReader br, List<Natality> creatures, List<Robot> robots) throws IOException {
        String[] input = br.readLine().split("\\s+");
        while (!input[0].equalsIgnoreCase("end")) {
            if (input[0].equalsIgnoreCase("citizen")) {
                Citizen citizen = new Citizen(input[1], Integer.valueOf(input[2]), input[3], input[4]);
                creatures.add(citizen);
            } else if (input[0].equalsIgnoreCase("pet")) {
                Pet pet = new Pet(input[1], input[2]);
                creatures.add(pet);
            } else {
                Robot robot = new Robot(input[1], input[2]);
                robots.add(robot);
            }
            input = br.readLine().split("\\s+");
        }
    }

}
