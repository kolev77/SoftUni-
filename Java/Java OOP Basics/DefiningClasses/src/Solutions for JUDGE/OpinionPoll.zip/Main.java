package LAB.Exercises.Person;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Rostislav Kolev on 08-Mar-17.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Integer n = Integer.valueOf(br.readLine());
        List<Person> people = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String[] input = br.readLine().split(" ");
            String name = input[0];
            Integer age = Integer.valueOf(input[1]);
            if (age > 30) {
                Person person = new Person(name, age);
                people.add(person);
            }
        }
        people.stream()
                .sorted((x, y) -> x.getName().compareTo(y.getName()))
                .forEach(x -> System.out.println(x));

    }
}
