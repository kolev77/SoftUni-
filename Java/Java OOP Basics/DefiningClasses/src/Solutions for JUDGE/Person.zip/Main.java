package LAB.Exercises.Person;

import java.lang.reflect.Field;

/**
 * Created by Rostislav Kolev on 08-Mar-17.
 */
public class Main {
    public static void main(String[] args) {
        Class person = Person.class;
        Field[] fields = person.getDeclaredFields();
        System.out.println(fields.length);
    }
}
