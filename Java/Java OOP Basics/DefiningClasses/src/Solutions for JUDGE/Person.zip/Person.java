package LAB.Exercises.Person;

/**
 * Created by Rostislav Kolev on 08-Mar-17.
 */
public class Person {
    private String name;
    private int age;
}
